<?php
// Redireccionamos a la vista login 
header('Location: vistas/login.html');
exit(); // Es una buena práctica añadir exit() después de un redireccionamiento para asegurarse de que el script no continúe ejecutándose.
?>
